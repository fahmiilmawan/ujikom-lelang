<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Ubah Lelang</title>
<body>
<?php 
include '../db.php';
$id = $_GET ['id'];
$db = new Database();
$data = $db->getById('lelang', ['id_lelang' => $id]);
foreach($data as $d):
?>
    <form action = "proses_ubah_lelang.php" method = "POST">
        <fieldset>
            <legend> Form Ubah Lelang </legend>
            <br>
            <label> Id Lelang </label>
            <br>
            <input type="text" name="id_lelang" placeholder="Id Lelang" value="<?php echo $d['id_lelang']; ?>" readonly>
            <br>
            <label> Id User </label>
            <br>
            <input type="text" name="id_user" placeholder="" value="<?php echo $d['id_user']; ?>" required>
            <br>
            <label> Id Barang </label>
            <br>
            <input type="text" name="id_barang" placeholder="id_barang" value="<?php echo $d['id_barang']; ?>" required>
            <br>
            <label> Id Petugas </label>
            <br>
            <input type="text" name="id_petugas" placeholder="id_petugas" value="<?php echo $d['id_petugas']; ?>" required>
            <br>
            <label> Tgl petugas </label>
            <br>
            <input type="date" name="tgl_lelang" placeholder="tgl_lelang" value="<?php echo $d['tgl_petugas']; ?>" >
            <br>
            <label> Harga Akhir </label>
            <br>
            <input type="integer" name="harga_akhir" placeholder="harga_akhir" value="<?php echo $d['harga_akhir']; ?>" required>
            <br>
            <label> status </label>
            <br>
            <select name="status">
                <option value="dibuka">Di Buka</option>
                <option value="ditutup">Di Tutup</option>
            </select>
            <br>
            <br>
<?php endforeach; ?>
<button type = 'submit'>Ubah</button>
        </fieldset>
    </form>
   
</body>
</html>