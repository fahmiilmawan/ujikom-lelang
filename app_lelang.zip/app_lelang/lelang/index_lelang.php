<?php 
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href=".../bootstrap/css/bootstrap.css">
    <title>App Lelang</title>
</head>
<body style="background-image:url('picture/7.jpg');background-repeat:no-repeat;background-size:cover;">
<body>

<center>
<br>
<a href="index.php" class='btn btn-warning'><h3><b>APLIKASI LELANG</b></h3></a> 
    <br>
    <br>

    <table border ="2" cellpadding "10">

    <tr>
        <th><center>Id Lelang</th>
        <th><center>Id Barang</th>
        <th><center>Tanggal Lelang</th>
        <th><center>Harga Akhir</th>
        <th><center>Id User</th>
        <th><center>Id Petugas</th>
        <th><center>Status</th>
        <th><center>Aksi</th>
    </tr>


    <?php 
    include "../db.php";
    $db = new Database();
    
    $data = $db->getAll('lelang');
    foreach($data as $d): ?>
    <tr> 
         <td><?php echo $d['id_lelang']; ?></td>
         <td><?php echo $d['id_barang']; ?></td>
         <td><?php echo $d['tgl_lelang']; ?></td>
         <td><?php echo $d['harga_akhir']; ?></td>
         <td><?php echo $d['id_user']; ?></td>
         <td><?php echo $d['id_petugas']; ?></td>
         <td><?php echo $d['status']; ?></td>
         <td>
            <a href="../lelang/form_ubah_lelang.php?id=<?php echo $d['id_lelang']; ?>"class='btn btn-success'>Ubah</a>
            |
            <a href="../lelang/proses_hapus_lelang.php?id=<?php echo $d['id_lelang']; ?>" onclick="return confirm('Apakah Anda Yakin Akan Menghapus Data Ini..? Jika yakin, jangan sampai melupakannya')" class='btn btn-danger'>Hapus</a>

        </td>
    </tr>
    <?php endforeach; ?>

    </table>
    <br>
            <a href="../lelang/form_tambah_lelang.php" class='btn btn-primary'>Tambah List</a>
    </center>

</body>
</html>