<?php

require '../db.php';
$db = new Database();

$id_lelang = $_POST['id_lelang'];
$status = $_POST['status'];

$query = mysqli_query($koneksi,"SELECT * FROM history_lelang 
INNER JOIN masyarakat ON history_lelang.id_user=masyarakat.id_user
INNER JOIN lelang ON history_lelang.id_lelang = lelang.id_lelang
INNER JOIN barang ON lelang.id_barang = barang.id_barang 
WHERE penawaran_harga = (SELECT MAX(penawaran_harga) FROM history_lelang
WHERE history_lelang.id_lelang='$id_lelang')");

 $data = mysqli_fetch_array($query,MYSQLI_ASSOC);
 $harga_akhir= $data['penawaran_harga'] ;
 

$update = $db->update('lelang', [
    'id_barang'     => $_POST['id_barang'],
    'tgl_lelang'    => $_POST['tgl_lelang'],
    'harga_akhir'   => $_POST['harga_akhir'],
    'id_user'       => $_POST['id_user'],
    'id_petugas'    => $_POST['id_petugas'], 
    'status'        => $status  
],
    ['id_barang'    =>$_POST['id_barang']]);

if ($update > 0) {
    if ($status = 'ditutup') {
        $update = $db -> update('lelang',[
            'harga_akhir' => $harga_akhir,
        ], 
        ['id_lelang' => $id_lelang]);
            header('Location:../applelang/index_lelang.php');
    }else{
        echo "gagal".mysqli_error($db->connect());
    }
}else{
    echo "gagal".mysqli_error($db->connect());
}