<?php

require '../db.php';

$db = new Database();
$insert = $db->insert('lelang', [
    'id_lelang'     =>'',
    'id_barang'     =>$_POST['id_barang'],
    'tgl_lelang'    =>$_POST['tgl_lelang'], 
    'harga_akhir'   =>$_POST['harga_akhir'],
    'id_user'       =>$_POST['id_user'],
    'id_petugas'    =>$_POST['id_petugas'],
    'status'        =>$_POST['status']
]);




if ( $insert > 0 ) {
    // Data berhasil dimasukkan
    header('Location:../applelang/index_lelang.php');
} else {
    echo mysqli_error($db->connect());
}
?>