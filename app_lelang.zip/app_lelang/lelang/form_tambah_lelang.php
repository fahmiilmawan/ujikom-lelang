<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>Form Tambah Lelang</title>
</head>
<body>
<?php
    include "../db.php";
    $db = new Database();
?>
    <form action = "proses_tambah_lelang.php" method = "POST">
        <fieldset>
            <legend> Form Tambah Lelang </legend>
            <br>
            <label> Nama Barang </label>
            <br>
            <select name="id_barang">
            <?php
            $barang = $db->getAll('barang');
            foreach ($barang as $b):
            ?>
                <option value="<?php echo $b['id_barang'];?>"><?php echo $b['nama_barang'];?></option>
            <?php endforeach;?>
            </select>
            <br>
            <label> Tanggal Lelang  </label>
            <br>
            <input type="date" name="tgl_lelang" placeholder="tanggal Lelang">
            <br>
            <label> Harga akhir</label>
            <br>
            <input type="text" name="harga_akhir" placeholder="Harga akhir"> 
            <br>
            <label> Nama Pengguna  </label>
            <br>
            <select name="id_user">
            <?php
            $masyarakat = $db->getAll('masyarakat');
            foreach ($masyarakat as $m):
            ?>
                <option value="<?php echo $m['id_user']; ?>"><?php echo $m['nama_lengkap']; ?></option>
            <?php endforeach;?>
            </select> 
            <br>
            <label> Nama Petugas  </label>
            <br>
            <select name="id_petugas">
            <?php
            $petugas = $db->getAll('petugas');
            foreach ($petugas as $p):
            ?>
                <option value="<?php echo $p['id_petugas']; ?>"><?php echo $p['nama_petugas']; ?></option>
            <?php endforeach;?>
            </select>
            <br>
            <label> status </label>
            <br>
            <select name="status">
                <option value="dibuka">Di Buka</option>
                <option value="ditutup">Di Tutup</option>
            </select>
            <br>
            <br>
            <button type="submit"> Tambah </button>
        </fieldset>
    </form>
</body>
</html>