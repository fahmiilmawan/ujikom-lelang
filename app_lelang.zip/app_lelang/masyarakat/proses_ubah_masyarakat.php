<?php

require '../db.php';
$password=$_POST['password_masyarakat'];
$hash=password_hash($password,PASSWORD_DEFAULT);
$db = new Database();
$update = $db->update('masyarakat', [
    'nama_lengkap'   => $_POST['nama_masyarakat'],
    'username'       => $_POST['username_masyarakat'],
    'password'       => $hash,
    'no_hp'          => $_POST['no_telpon_masyarakat'] 
],
    ['id_user'       =>$_POST['id_masyarakat']]);

if ( $update > 0 ) {
    // Data berhasil diubah
    header('Location:../applelang/index_masyarakat.php');
} else {
    echo mysqli_error($db->connect());
}