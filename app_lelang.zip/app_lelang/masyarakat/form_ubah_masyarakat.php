<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Ubah Masyarakat</title>
<body>
<?php 
include '../db.php';
$id = $_GET ['id'];
$db = new Database();
$data = $db->getById('masyarakat', ['id_user' => $id]);
foreach($data as $d):
?>
    <form action = "proses_ubah_masyarakat.php" method = "POST">
        <fieldset>
            <legend> Form Ubah masyarakat </legend>
            <br>
            <label> Id User </label>
            <br>
            <input type="text" name="id_masyarakat" placeholder="ID User" value="<?php echo $d['id_user']; ?>" readonly>
            <br>
            <label> Nama Lengkap </label>
            <br>
            <input type="text" name="nama_masyarakat" placeholder="Nama Lengkap" value="<?php echo $d['nama_lengkap']; ?>" required>
            <br>
            <label> Username </label>
            <br>
            <input type="text" name="username_masyarakat" placeholder="username" value="<?php echo $d['username']; ?>" required>
            <br>
            <label> Password </label>
            <br>
            <input type="password" name="password_masyarakat" placeholder="password" value="<?php echo $d['password']; ?>" required>
            <br>
            <label> No Telpon </label>
            <br>
            <input type="text" name="no_telpon_masyarakat" placeholder="No Telpon" value="<?php echo $d['no_hp'];?>">
            <br>
<?php endforeach; ?>
<button type = 'submit'>Ubah</button>
        </fieldset>
    </form>
   
</body>
</html>