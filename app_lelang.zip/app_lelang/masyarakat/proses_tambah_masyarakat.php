<?php

require '../db.php';

$password= $_POST['password_masyarakat'];
$hash = password_hash($passsword,PASSWORD_DEFAULT);
$db = new Database();
$insert = $db->insert('masyarakat', [
    'id_user'        =>'',
    'nama_lengkap'   =>$_POST['nama_masyarakat'],
    'username'       =>$_POST['username_masyarakat'], 
    'password'       =>$hash,
    'no_telpon'      =>$_POST['no_telpon_masyarakat']
]);

if ( $insert > 0 ) {
    // Data berhasil dimasukkan
    header('Location:../applelang/index_masyarakat.php');
} else {
    echo mysqli_error($db->connect());
}
?>