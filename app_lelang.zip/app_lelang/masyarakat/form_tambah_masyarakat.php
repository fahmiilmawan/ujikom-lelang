<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>Form Tambah Masyarakat</title>
</head>
<body>
<form action = "proses_tambah_masyarakat.php" method = "POST">
        <fieldset>
            <legend> Form Tambah Masyarakat </legend>
            <br>
            <label> Nama Lengkap </label>
            <br>
            <input type="text" name="nama_masyarakat" placeholder="Nama Lengkap">
            <br>
            <label> Username </label>
            <br>
            <input type="text" name="username_masyarakat" placeholder="Username">
            <br>
            <label> Password </label>
            <br>
            <input type="password" name="password_masyarakat" placeholder="Password">
            <br>
            <label> No Telpon </label>
            <br>
            <input type="text" name="no_telpon_masyarakat" placeholder="No Telpon">
            <br>
            <br>
            <button type="submit"> Tambah </button>
        </fieldset>
    </form>
</body>
</html>