<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>Form Tambah Petugas</title>
</head>
<body>
<form action = "proses_tambah_petugas.php" method = "POST">
        <fieldset>
            <legend> Form Tambah Petugas </legend>
            <br>
            <label> Nama Lengkap </label>
            <br>
            <input type="text" name="nama_petugas" placeholder="Nama Lengkap">
            <br>
            <label> Username </label>
            <br>
            <input type="text" name="username_petugas" placeholder="Username">
            <br>
            <label> Password </label>
            <br>
            <input type="password" name="password_petugas" placeholder="Password">
            <br>
            <label> Level </label>
            <br>
            <select name="id_level" id="">
            <option value="1">Admin</option>
            <option value="2">Petugas</option>
            </select>
            <br>
            <br>
            <button type="submit"> Tambah </button>
        </fieldset>
    </form>
</body>
</html>