<?php

require '../db.php';
$password=$_POST['password'];
$hash=password_hash($password,PASSWORD_DEFAULT);
$db = new Database();
$update = $db->update('petugas', [
    'nama_petugas'   => $_POST['nama_petugas'],
    'username'       => $_POST['username_petugas'],
    'password'       => $hash,
    'id_level'          => $_POST['id_level'] 
],
    ['id_petugas'       =>$_POST['id_petugas']]);

if ( $update > 0 ) {
    // Data berhasil diubah
    header('Location:../applelang/index_petugas.php');
} else {
    echo mysqli_error($db->connect());
}