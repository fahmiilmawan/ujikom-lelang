<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>Form Tambah Histori Lelang</title>
</head>
<body>
<?php
    include "../db.php";
    $db = new Database();
?>
    <form action = "proses_tambah_history_lelang.php" method = "POST">
        <fieldset>
            <legend> Form Tambah  Histori Lelang </legend>
            <br>
            <label> ID Lelang </label>
            <br>
            <select name="id_lelang">
            <?php
            $lelang = $db->getAll('lelang');
            foreach ($lelang as $l):
            ?>
                <option value="<?php echo $l['id_lelang'];?>"> <?php echo $l ['id_lelang'];?></option>
            <?php endforeach;?>
            </select>
            <br>
            <label> ID User </label>
            <br>
            <select name="id_user">
            <?php
            $masyarakat = $db->getAll('masyarakat');
            foreach ($masyarakat as $u):
            ?>
                <option value="<?php echo $u['id_user'];?>"><?php echo $u['nama_lengkap'];?></option>
            <?php endforeach;?>
            </select>
            <br>
            <label> Penawaran Harga  </label>
            <br>
            <input type="number" name="penawaran_harga" placeholder="Penawaran Harga">
            <br>
            <br>
            <button type="submit"> Tambah </button>
        </fieldset>
    </form>
</body>
</html>