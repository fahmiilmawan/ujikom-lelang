<?php 
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href=".../bootstrap/css/bootstrap.css">
    <title>History Lelang</title>
</head>
<body style="background-image:url('picture/7.jpg');background-repeat:no-repeat;background-size:cover;">
<body>

<center>
<br>
<a href="index.php" class='btn btn-warning'><h3><b>APLIKASI LELANG</b></h3></a> 
    <br>
    <br>

    <table border ="2" cellpadding "10">

    <tr>
        <th><center>Id History</th>
        <th><center>Id Lelang</th>
        <th><center>Id User</th>
        <th><center>Penawaran Harga</th>
    </tr>


    <?php 
    $db = new Database();
    
    $data = $db->getAll('history_lelang');
    foreach($data as $d): ?>
    <tr> 
         <td><?php echo $d['id_history']; ?></td>
         <td><?php echo $d['id_lelang']; ?></td>
         <td><?php echo $d['id_user']; ?></td>
         <td><?php echo $d['penawaran_harga']; ?></td>
         <td>
            <a href="form_ubah_history_lelang.php?id=<?php echo $d['id_history']; ?>"class='btn btn-success'>Ubah</a>
            |
            <a href="proses_hapus_history_lelang.php?id=<?php echo $d['id_history']; ?>" onclick="return confirm('Apakah Anda Yakin Akan Menghapus Data Ini..? Jika yakin, jangan sampai melupakannya')" class='btn btn-danger'>Hapus</a>

        </td>
    </tr>
    <?php endforeach; ?>

    </table>
    <br>
            <a href="form_tambah_history_lelang.php" class='btn btn-primary'>Tambah List</a>
    </center>

</body>
</html>