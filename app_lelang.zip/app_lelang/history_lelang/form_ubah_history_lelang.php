<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Ubah History Lelang</title>
<body>
<?php 
include '../db.php';
$id = $_GET ['id'];
$db = new Database();
$data = $db->getById('history_lelang', ['id_history' => $id]);
foreach($data as $d):
?>
    <form action = "proses_ubah_history_lelang.php" method = "POST">
        <fieldset>
            <legend> Form Ubah History Lelang </legend>
            <br>
            <label> Id History </label>
            <br>
            <input type="text" name="id_history" placeholder="Id history" value="<?php echo $d['id_history']; ?>" readonly>
            <br>
            <label> Id lelang </label>
            <br>
            <input type="text" name="id_lelang" placeholder="id_barang" value="<?php echo $d['id_lelang']; ?>" required>
            <br>
            <label> Id User </label>
            <br>
            <input type="text" name="id_user" placeholder="" value="<?php echo $d['id_user']; ?>" required>
            <br>
            <label> Penawaran Harga </label>
            <br>
            <input type="integer" name="penawaran_harga" placeholder="harga_akhir" value="<?php echo $d['penawaran_harga']; ?>" required>
            <br>
            <br>
<?php endforeach; ?>
<button type = 'submit'>Ubah</button>
        </fieldset>
    </form>
   
</body>
</html>