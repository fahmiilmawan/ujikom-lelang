<?php

require '../db.php';

$db = new Database();
$update = $db->update('history_lelang', [
    'id_lelang'    => $_POST['id_lelang'],
    'id_user'       => $_POST['id_user'],
    'penawaran_harga'    => $_POST['penawaran_harga']
],
    ['id_history'    =>$_POST['id_history']]);

if ( $update > 0 ) {
    // Data berhasil diubah
    header('Location:../applelang/index_history.php');
} else {
    echo mysqli_error($db->connect());
}