<?php

require '../db.php';

$db = new Database();
$insert = $db->insert('history_lelang', [
    'id_history'     =>'',
    'id_lelang'    =>$_POST['id_lelang'], 
    'id_user'       =>$_POST['id_user'],
    'penawaran_harga' =>$_POST['penawaran_harga']
]);




if ( $insert > 0 ) {
    // Data berhasil dimasukkan
    header('Location:../applelang/index_history.php');
} else {
    echo mysqli_error($db->connect());
}
?>