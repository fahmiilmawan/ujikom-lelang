<?php
session_start();
include "../db.php";

$db = new Database();

$id          = $_POST['id_lelang'];
$penawaran   = $_POST['penawaran'];
$id_user     = $_SESSION['id_user'];

$insert = $db->insert('history_lelang',[
    'id_history'        =>'',
    'id_lelang'         =>$id,
    'id_user'           =>$id_user,
    'penawaran_harga'   =>$penawaran
]);
if ($insert > 0) {
    header('location:index_user_lelang.php');
}else{
    echo"gagal gaesss".mysqli_error($db->connect());
}

?>