<?php
    include "../db.php";
    $id_lelang = $_GET['id_lelang'];

    $query = mysqli_query($koneksi,"SELECT * FROM history_lelang 
    INNER JOIN masyarakat ON history_lelang.id_user=masyarakat.id_user
    INNER JOIN lelang ON history_lelang.id_lelang = lelang.id_lelang
    INNER JOIN barang ON lelang.id_barang = barang.id_barang 
    WHERE penawaran_harga = (SELECT MAX(penawaran_harga) FROM history_lelang
    WHERE history_lelang.id_lelang='$id_lelang')");

    $data = mysqli_fetch_array($query,MYSQLI_ASSOC);
    $harga_akhir = $data['penawaran_harga'];
    $foto = $data['img'];
    $nama = $data['nama_lengkap'];

    if ($query == TRUE) {
        
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
        <title>Pemenang</title>
    </head>
    <body>
    <div class="col-lg-5"style="text-align:center;margin-left:320px;margin-top:50px;">
         <div class="card" style=" margin-left:100px;box-shadow: 10px 10px 10px 5px rgba(0,0,0,0.5);background-color:#9c27b0; ">
          <img src="../pictures/<?php echo $foto?>" class="card-img-top"  style="padding:20px;"alt="...">
          <?php?>
        <div class="card-body" style="background-color:white;border:1px solid black;">
            <h5 class="card-title">Selamat Kepada <?php echo $nama?>,</h5>
              <p class="card-text"> Harga Akhir : <?php echo $harga_akhir?></p>
              <p class="card-text"> </p>
              <p class="card-text"> </p>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
     }
        else{
            echo "gagal";
        }
    ?>