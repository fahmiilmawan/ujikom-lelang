<!doctype html>
<html lang="en">

<head>
  <title>Lelang App</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"> -->
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <script defer src="../tampilan_awal/fontawesome5//svg-with-js/js/fontawesome-all.min.js"></script>
</head>

<body>
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini" style="color:#9c27b0">
        <i class="fas fa-gavel" style="color:#9c27b0;background-color:white;border:1px solid #9c27b0 ;width:50px;height:50px;border-radius:100%;margin-right:0px;"></i>Lelang App </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
<!-- AKSES ADMIN -->
<li class="nav-item active  ">
  <a class="nav-link" href="index_masyarakat.php">
    <i class="fas fa-user"></i>
    <p>User</p>
  </a>
</li>
<li class="nav-item active  ">
  <a class="nav-link" href="index_petugas.php">
    <i class="fas fa-user-secret"></i>
    <p>Petugas</p>
  </a>
</li>
<li class="nav-item active  ">
  <a class="nav-link" href="index_barang.php">
    <i class="fas fa-archive"></i>
    <p>Barang</p>
  </a>
</li>
<li class="nav-item active  ">
  <a class="nav-link" href="index_history.php">
    <i class="fas fa-history"></i>
    <p>History</p>
  </a>
</li>
<li class="nav-item active  ">
  <a class="nav-link" href="index_lelang.php">
    <i class="fas fa-gavel"></i>
    <p>Lelang</p>
  </a>
</li>
          <br><br><br><br><br>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Dashboard
              <br><br><br><br><br><br><br>
            </a>
            
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:;">
                  <i class="material-icons">notifications</i> Notifications
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <table border ="2" cellpadding "10" style="text-align:center;box-shadow: 10px 10px 10px 5px rgba(0,0,0,0.5);">
          <thead class="" style="background-color:#9c27b0;color:white;">

    <tr>
        <th class="col"><center>Id Lelang</th>
        <th class="col"><center>Id Barang</th>
        <th class="col"><center>Tanggal Lelang</th>
        <th class="col"><center>Harga Akhir</th>
        <th class="col"><center>Id User</th>
        <th class="col"><center>Id Petugas</th>
        <th class="col"><center>Status</th>
        <th class="col"><center>Aksi</th>
    </tr>
    </thead>


    <?php 
    include "../db.php";
    $db = new Database();
    
    $data = $db->getAll('lelang');
    foreach($data as $d): ?>
    <tr> 
         <td class="col"><?php echo $d['id_lelang']; ?></td>
         <td class="col"><?php echo $d['id_barang']; ?></td>
         <td class="col"><?php echo $d['tgl_lelang']; ?></td>
         <td class="col"><?php echo $d['harga_akhir']; ?></td>
         <td class="col"><?php echo $d['id_user']; ?></td> 
         <td class="col"><?php echo $d['id_petugas']; ?></td>
         <td class="col"><?php echo $d['status']; ?></td>
         <td><a href="../lelang/form_ubah_lelang.php?id=<?php echo $d['id_lelang'];?>" class="btn btn-success">Ubah</a>
         |
         <a href="../lelang/proses_hapus_lelang.php?id=<?php echo $d['id_lelang']?>" class="btn btn-danger">Hapus</a>
         </td>
         
    </tr>
    <?php endforeach; ?>

    </table>
    <br>
            <a href="../lelang/form_tambah_lelang.php" class='btn btn-primary'>Tambah List</a>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
          <!-- your footer here -->
        </div>
      </footer>
    </div>
  </div>
</body>

</html>