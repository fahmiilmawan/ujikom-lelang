<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Penawaran</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="bootstrap/css/style.css">
</head>

<center>
<b><div class="alert alert-primary" role="alert">
   <h1> Penawaran  </div> </h1> </b>
<br>
<?php
    include "../db.php";

    $db= new Database();
    $id=$_GET['id'];
    $data = $db->getById('lelang',['id_lelang'=>$id]);


?>
<?php foreach($data as $d):endforeach;?>
<form action="proses_penawaran.php" method="POST">
     
    <legend>Masukan Penawaran Anda</legend>
    <br>
    <label>Id Lelang:</label><br>
    <input name= "id_lelang" type= "id_lelang" placeholder="Id Lelang" value="<?php echo $d['id_lelang'];?>" required><br>
    <label>Tawar:</label><br>
    <input name= "penawaran" type="number" placeholder="Tawar"required><br></i>
    <br>
    <button class="btn btn-primary">Submit</button>
    </form>
    