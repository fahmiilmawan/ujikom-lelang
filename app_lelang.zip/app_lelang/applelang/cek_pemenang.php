<?php
    include "../db.php";
    session_start();
    $id_lelang = $_GET['id'];

    $query = mysqli_query($koneksi, "SELECT * FROM history_lelang INNER JOIN masyarakat ON history_lelang.id_user = masyarakat.id_user INNER JOIN lelang ON history_lelang.id_lelang = lelang.id_lelang INNER JOIN barang ON lelang.id_barang = barang.id_barang WHERE penawaran_harga = (SELECT MAX(penawaran_harga) FROM history_lelang) ");

    $lv = mysqli_fetch_array($query, MYSQLI_ASSOC);
    $hrg_akhir = $lv['penawaran_harga'];
        $nama = $lv['nama_lengkap'];
        $foto = $lv['img'];
        $nama_barang = $lv['nama_barang'];
        $deskripsi = $lv['deskripsi'];

        if ($query == TRUE) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <title>PEMENANG</title>
</head>
<body>
<div class="col-md-4">
         <div class="card" style="width: 18rem;">
<img src="../pictures/<?php echo $foto;?>" class="card-img-top" alt="...">
          <?php?>
        <div class="card-body">
            <h5 class="card-title"><?php echo $nama_barang?></h5>
            <p class="card-text"> Atas Nama : <?php echo $nama?></p>
              <p class="card-text"> Harga Akhir : <?php echo $hrg_akhir?></p>
              <p class="card-text"> Deskripsi : <?php echo $deskripsi?></p>
                <a href="index_user_history.php" class="btn btn-primary">Kembali</a>
        </div>
          </div>
          </div>


</body>
</html>

<?php
        }else{
            echo "Gagal...".mysqli_error($koneksi);
        }
?>