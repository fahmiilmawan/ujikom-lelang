<!doctype html>
<html lang="en">

<head>
  <title>Lelang App</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"> -->
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <script defer src="../tampilan_awal/fontawesome5//svg-with-js/js/fontawesome-all.min.js"></script>
</head>

<body style="background-color:#eee;">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini" style="color:#9c27b0">
        <i class="fas fa-gavel" style="color:#9c27b0;background-color:white;border:1px solid #9c27b0 ;width:50px;height:50px;border-radius:100%;margin-right:0px;"></i>Lelang App </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <!-- AKSES USER -->
          <li class="nav-item active  ">
            <a class="nav-link" href="index_user_lelang.php">
              <i class="fas fa-gavel"></i>
              <p>Lelang</p>
            </a>
          </li>
          <?php
          session_start();
          ?>
          <br><br><br><br><br>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;"> 
              <br><br><br><br><br><br><br>
            </a>
            
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:;">
                <a href ="../tampilan_awal/proses_logout_user.php" onclick="return confirm('Apakah Anda Yakin Akan Keluar dari halaman ini..? Jika Anda yakin, jangan lupa untuk balik lagi')" class = "btn btn-danger">Logout</a>
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
          <h1>Selamat Datang, <?php echo $_SESSION['nama_lengkap']; ?></h1>
          
          <div class="card" style="width:900px;padding:25px; background-color:#9c27b0;box-shadow: 10px 10px 10px 5px rgba(0,0,0,0.5);border: 1px solid white;">
          <h1 style="color:white;">Lelang</h1>
          </div>
          
          
    
    <!-- LELANG GABUNG BARANG -->
    <?php
    include "../db.php"; 
    $db = new Database();
    $query= mysqli_query($koneksi,"SELECT * FROM lelang INNER JOIN barang ON lelang.id_barang=barang.id_barang WHERE lelang.status='dibuka'");
     ?>
     <!-- ---------------------------------------------------------------->
     
      <div class="row row-cols-1 row-cols-md-3">
      
      <?php  while($h=mysqli_fetch_assoc($query)):?>
        
       
    
        
         <div class="card col-sm-3" style=" margin-left:50px;box-shadow: 10px 10px 10px 5px rgba(0,0,0,0.5);background-color:#9c27b0; ">
          <img src="../pictures/<?php echo $h['img'];?>" class="card-img-top"  style="padding:20px;"alt="...">
          <?php?>
        <div class="card-body" style="background-color:white;border:1px solid black;margin-bottom:20px;;">
            <h5 class="card-title"><?php echo $h['nama_barang'];?></h5>
              <p class="card-text"> Tanggal : <?php echo $h['tanggal'];?></p>
              <p class="card-text"> Harga Awal : <?php echo $h['harga_awal'];?></p>
              <p class="card-text"> Deskripsi : <?php echo $h['deskripsi'];?></p>
                <a href="form_penawaran.php?id=<?php echo $h['id_lelang']?>" class="btn btn-primary" style="font-size:15px;width:100px;">Tawar</a>
                <?php 
        $id=$h['id_lelang'];
        $tampil=mysqli_query($koneksi,"SELECT penawaran_harga FROM history_lelang WHERE id_lelang='$id'");
        $jumlah = mysqli_num_rows($tampil);

    if($jumlah > 0){?>
        <a style="width:200px;font-size:15px; margin-top:4px;" href="proses_pemenang.php?id_lelang=<?php echo $h['id_lelang']; ?>" class="btn btn-info ">Pemenang Lelang!</a>
        <?php }?>
        </div>
          </div>
        
          
      <?php endwhile; ?>
 </div>
        
</div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="">
                  Creative Tim
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, Made with <i class="material-icons">Ketulusan</i> by
            <a href="" target="_blank">Creative Tim</a> for a better web.
          </div>
          <!-- your footer here -->
        </div>
      </footer>
    </div>
  </div>
</body>

</html>