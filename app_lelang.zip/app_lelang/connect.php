<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'lelang';

$koneksi= mysqli_connect($host,$username,$password,$database);





?>