<?php 
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>App Lelang</title>
</head>
<body style="background-image:url('picture/7.jpg');background-repeat:no-repeat;background-size:cover;">
<body>
    
<center>
<br>
<a class='btn btn-warning'><h3><b>APLIKASI LELANG</b></h3></a> 
    <br>
    <br>

    <table border ="2" cellpadding "10">

    <tr>
        <th><center>Id Barang</th>
        <th><center>Nama Barang</th>
        <th><center>Tanggal</th>
        <th><center>Harga Awal</th>
        <th><center>Deskripsi</th>
        <th><center>Aksi</th>
    </tr>


    <?php
    include "../db.php"; 
    $db = new Database();
    
    $data = $db->getAll('barang');
    foreach($data as $d): ?>
    <tr> 
         <td><?php echo $d['id_barang']; ?></td>
         <td><?php echo $d['nama_barang']; ?></td>
         <td><?php echo $d['tanggal']; ?></td>
         <td><?php echo $d['harga_awal']; ?></td>
         <td><?php echo $d['deskripsi']; ?></td>
         <td>
            <a href="form_ubah_barang.php?id=<?php echo $d['id_barang']; ?>"class='btn btn-success'>Ubah</a>
            |
            <a href="proses_hapus_barang.php?id=<?php echo $d['id_barang']; ?>" onclick="return confirm('Apakah Anda Yakin Akan Menghapus Data Ini..? Jika yakin, jangan sampai melupakannya')" class='btn btn-danger'>Hapus</a>

        </td>
    </tr>
    <?php endforeach; ?>

    </table>
    <br>
            <a href="form_tambah_barang.php" class='btn btn-primary'>Tambah List</a>
    </center>


</body>
</html>