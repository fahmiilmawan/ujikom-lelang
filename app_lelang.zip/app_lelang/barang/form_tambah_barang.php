<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Tambah Lelang</title>
</head>
<body>
    <form action = "proses_tambah_barang.php" method = "POST" enctype="multipart/form-data">
        <fieldset>
            <legend> Form Tambah Lelang </legend>
            <br>
            <label> Nama Barang </label>
            <br>
            <input type="text" name="nama_barang" placeholder="Nama barang">
            <br>
            <label> tanggal </label>
            <br>
            <input type="date" name="tanggal" placeholder="tanggal">
            <br>
            <label> harga awal </label>
            <br>
            <input type="bigint" name="harga_awal" placeholder="harga awal">
            <br>
            <label> Deskripsi </label>
            <br>
            <textarea name="deskripsi" placeholder="Deskripsi" cols="30" rows="10"></textarea>
            <br>
            <label> Pilih Foto </label>
            <br>
            <input type="file" name="file" placeholder="Pilih foto">
            <br>
            <br>
            <button type="submit" name="upload"> Tambah </button>
        </fieldset>
    </form>
</body>
</html>