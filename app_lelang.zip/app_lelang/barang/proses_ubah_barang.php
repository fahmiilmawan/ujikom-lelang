<?php

require '../db.php';

$db = new Database();
$update = $db->update('barang', [
    'nama_barang'   => $_POST['nama_barang'],
    'tanggal'       => $_POST['tanggal'],
    'harga_awal'    => $_POST['harga_awal'],
    'deskripsi'     => $_POST['deskripsi'] 
],
    ['id_barang'    =>$_POST['id_barang']]);

if ( $update > 0 ) {
    // Data berhasil diubah
    header('Location:../applelang/index_barang.php');
} else {
    echo mysqli_error($db->connect());
}