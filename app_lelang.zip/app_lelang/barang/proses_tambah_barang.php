<?php

require '../db.php';
include "../connect.php";


$kode = mysqli_query($koneksi,"SELECT * FROM barang");
if ( isset($_POST["upload"])) {

$nama_barang        =$_POST['nama_barang'];
$tgl                =$_POST['tanggal'];
$harga_awal         =$_POST['harga_awal'];
$deskripsi          =$_POST['deskripsi'];

    // simpan gambar
    $ekstensi_diperbolehkan = array('jpg','png');
    $nama = $_FILES['file']['name'];
    $x = explode('.', $nama);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['file']['size'];
    $file_temp = $_FILES['file']['tmp_name'];

    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
        if($ukuran < 1044070){
            move_uploaded_file($file_temp, '../pictures/'.$nama);
            $query = mysqli_query($koneksi, "INSERT INTO barang VALUES ('', 
            '$nama_barang', '$tgl', '$harga_awal','$deskripsi','$nama')");
            if($query){
                header('location:../applelang/index_barang.php');
            } else{
                echo "gagal menambahkan data".mysqli_error($koneksi);
            }
        }else{
            echo"ukuran terlalu besar";
        }

    }else{
        echo"tidak diperbolehkan";
    }
}
//     $kode = mysqli_query($koneksi,"SELECT * FROM tb_barang");
//     if ( isset($_POST['upload'])) {
        
//     $nama_barang    =$_POST['nama_barang'],
//     $tgl            =$_POST['tanggal'], 
//     $harga_awal     =$_POST['harga_awal'],
//     $deskripsi      =$_POST['deskripsi']
// //    SIMPAN GAMBAR   
//         $
//     }

// if ( $insert > 0 ) {
//     // Data berhasil dimasukkan
//     header('Location:../applelang/index_barang.php');
// } else {
//     echo mysqli_error($db->connect());
// }
?>